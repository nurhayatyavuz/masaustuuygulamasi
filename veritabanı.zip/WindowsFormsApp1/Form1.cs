﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
      

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            videolar anasyf = new videolar();
            anasyf.ShowDialog();
        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {

        }

        private void backgroundWorker11_DoWork(object sender, DoWorkEventArgs e)
        {

        }

        private void backgroundWorker12_DoWork(object sender, DoWorkEventArgs e)
        {

        }

        private void backgroundWorker13_DoWork(object sender, DoWorkEventArgs e)
        {

        }

        private void btngirs_Click(object sender, EventArgs e)
        {
            giriskisim anasyf = new giriskisim();
            anasyf.ShowDialog();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            kitaplar anasyf = new kitaplar();
            anasyf.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            seskayit anasyf = new seskayit();
            anasyf.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            notlar anasyf = new notlar();
            anasyf.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
            
        }

        private void checkedListBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            mailgönderme anasyf = new mailgönderme();
            anasyf.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            tamamlananlarcs anasyf = new tamamlananlarcs();
            anasyf.ShowDialog();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
