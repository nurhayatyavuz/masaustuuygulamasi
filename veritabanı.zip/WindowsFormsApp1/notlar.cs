﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class notlar : Form
    {
        SqlConnection baglanti2;
        SqlCommand komut2;
        SqlDataAdapter da2;
        public notlar()
        {
            InitializeComponent();
        }
        void notlarim()
        {
            baglanti2 = new SqlConnection("server=.; Initial Catalog=notlar ; Integrated Security=SSPI");
            baglanti2.Open();
            da2 = new SqlDataAdapter("SELECT *FROM submission", baglanti2);
            DataTable tablo5 = new DataTable();
            da2.Fill(tablo5);
            dataGridView3.DataSource = tablo5;
            baglanti2.Close();
        }

            private void notlar_Load(object sender, EventArgs e)
            {
                notlarim();
            }

            private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
            {

            }
        }
    }

