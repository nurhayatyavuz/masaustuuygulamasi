﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class seskayit : Form
    {
        SqlConnection baglanti2;
        SqlCommand komut2;
        SqlDataAdapter da1;
        public seskayit()
        {
            InitializeComponent();
        }
        void girisayi()
        {
            baglanti2 = new SqlConnection("server=.; Initial Catalog=dersesler ; Integrated Security=SSPI");
            baglanti2.Open();
            da1 = new SqlDataAdapter("SELECT *FROM Sayfa1$", baglanti2);
            DataTable tablo = new DataTable();
            da1.Fill(tablo);
            dataGridView2.DataSource = tablo;
            baglanti2.Close();

        }
        void arama()
        {
            baglanti2 = new SqlConnection("server=.; Initial Catalog=dersesler ; Integrated Security=SSPI");
            baglanti2.Open();
            SqlCommand komut2 = new SqlCommand("SELECT *FROM Sayfa1$ where DERSLER like '%" + textses.Text + "%'", baglanti2);
            SqlDataAdapter da1 = new SqlDataAdapter(komut2);
            DataSet tablo = new DataSet();
            da1.Fill(tablo);
            dataGridView2.DataSource = tablo.Tables[0];
            baglanti2.Close();

        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void seskayit_Load(object sender, EventArgs e)
        {
            girisayi();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            arama();
        }
    }
}
