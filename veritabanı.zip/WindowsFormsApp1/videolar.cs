﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class videolar : Form
    {
        SqlConnection baglanti3;
        SqlCommand komut3;
        SqlDataAdapter da3;
        public videolar()
        {
            InitializeComponent();
        }
        void videokayit()
        {
            baglanti3 = new SqlConnection("server=.; Initial Catalog=videolar ; Integrated Security=SSPI");
            baglanti3.Open();
            da3 = new SqlDataAdapter("SELECT *FROM Sayfa1$", baglanti3);
            DataTable tablo6 = new DataTable();
            da3.Fill(tablo6);
            dataGridView4.DataSource = tablo6;
            baglanti3.Close();

        }
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void videolar_Load(object sender, EventArgs e)
        {
            videokayit();
        }
    }
}
