﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Mail;

namespace WindowsFormsApp1
{
    public partial class mailgönderme : Form
    {
        public mailgönderme()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MailMessage mesajım1= new MailMessage();
            SmtpClient istemcim =new SmtpClient();
            istemcim.Credentials = new System.Net.NetworkCredential("mlsbn.bn@gmail.com", "2000nur.");// şifre ve mail girilecek
            istemcim.Port = 587;
            istemcim.Host = "smtp.gmail.com";
            istemcim.EnableSsl = true;
            mesajım1.To.Add(kime.Text);
            mesajım1.From = new MailAddress("mlsbn.bn@gmail.com");
            mesajım1.Subject=konu.Text;
            mesajım1.Body = body.Text;
           // istemcim.Send(mesajım1);





        }

        private void mailgönderme_Load(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
