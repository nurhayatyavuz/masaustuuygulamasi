﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace WindowsFormsApp1
{
    public partial class tamamlananlarcs : Form
    {
        SqlConnection baglantim;
        SqlCommand komut2;
        SqlDataAdapter da1;
        public tamamlananlarcs()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void tamamlananlarcs_Load(object sender, EventArgs e)
        {
            baglantim = new SqlConnection("server=.; Initial Catalog=denemeler ; Integrated Security=SSPI");
            baglantim.Open();
            da1 = new SqlDataAdapter("SELECT *FROM denemeler", baglantim);
            DataTable tablo = new DataTable();
            da1.Fill(tablo);
            dataGridView10.DataSource = tablo;
            baglantim.Close();
        }
        void verilerigoster(string veriler)
        {
            SqlDataAdapter da1 = new SqlDataAdapter(veriler, baglantim);
            DataSet tablo = new DataSet();
            da1.Fill(tablo);
            dataGridView10.DataSource = tablo.Tables[0];
        }

        private void deneme_Click(object sender, EventArgs e)
        {
            baglantim.Open();
            SqlCommand komut2 = new SqlCommand("insert into denemeler(dersadi,dersonuc) values (@dersadi,@dersonuc)", baglantim);
            komut2.Parameters.AddWithValue("@dersadi", denemeadi.Text);
            komut2.Parameters.AddWithValue("@dersonuc", denemesonuc.Text);
            komut2.ExecuteNonQuery();
            verilerigoster ("SELECT *FROM denemeler");
            baglantim.Close();  

        }

        private void denemesil_Click(object sender, EventArgs e)
        {
            baglantim.Open();
            SqlCommand komut2 = new SqlCommand("delete from denemeler where dersadi=@dersadi", baglantim);
            komut2.Parameters.AddWithValue("@dersadi",denemeadi.Text);
            komut2.ExecuteNonQuery();
            verilerigoster("SELECT *FROM denemeler");
            baglantim.Close();

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
