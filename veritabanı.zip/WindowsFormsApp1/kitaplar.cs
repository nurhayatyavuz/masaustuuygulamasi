﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp1
{
    public partial class kitaplar : Form
    {
        SqlConnection baglanti2;
        SqlCommand komut2;
        SqlDataAdapter da1;
        public kitaplar()
        {
            InitializeComponent();
        }
        
        void kitapsayi()
        {
            baglanti2 = new SqlConnection("server=.; Initial Catalog=kutuphaneyeni ; Integrated Security=SSPI");
            baglanti2.Open();
            da1 = new SqlDataAdapter("SELECT *FROM kitap", baglanti2);
            DataTable tablo= new DataTable();
            da1.Fill(tablo);
            dataGridView1.DataSource = tablo;
            baglanti2.Close(); // methot yaptık tekrardan yazmamaz için 

        }

        private void kitaplar_Load(object sender, EventArgs e)
        {
            kitapsayi();
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
           
        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
           
        {
           
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)

        {
            baglanti2 = new SqlConnection("server=.; Initial Catalog=kutuphaneyeni ; Integrated Security=SSPI");
            baglanti2.Open();
            SqlCommand komut2 = new SqlCommand("SELECT *FROM kitap where ad like '%"+textara.Text+"%'",baglanti2);
            SqlDataAdapter da1= new SqlDataAdapter(komut2); 
            DataSet tablo=new DataSet();
            da1.Fill(tablo);
            dataGridView1.DataSource = tablo.Tables[0];
            baglanti2.Close();

        }
    }
}
