﻿namespace WindowsFormsApp1
{
    partial class tamamlananlarcs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.checkedListBox1 = new System.Windows.Forms.CheckedListBox();
            this.dataGridView10 = new System.Windows.Forms.DataGridView();
            this.deneme = new System.Windows.Forms.Button();
            this.denemeadi = new System.Windows.Forms.TextBox();
            this.denemesonuc = new System.Windows.Forms.TextBox();
            this.denemesil = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView10)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label1.Location = new System.Drawing.Point(34, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "TAMAMLADIKLARIM:";
            this.label1.UseWaitCursor = true;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.Info;
            this.textBox1.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.textBox1.Location = new System.Drawing.Point(37, 91);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(206, 264);
            this.textBox1.TabIndex = 1;
            this.textBox1.UseWaitCursor = true;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // checkedListBox1
            // 
            this.checkedListBox1.BackColor = System.Drawing.SystemColors.Info;
            this.checkedListBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.checkedListBox1.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.checkedListBox1.FormattingEnabled = true;
            this.checkedListBox1.Items.AddRange(new object[] {
            "Dersler",
            "Not Aldıklarım",
            "Denemeler",
            "..."});
            this.checkedListBox1.Location = new System.Drawing.Point(58, 223);
            this.checkedListBox1.Name = "checkedListBox1";
            this.checkedListBox1.Size = new System.Drawing.Size(120, 104);
            this.checkedListBox1.TabIndex = 2;
            this.checkedListBox1.UseWaitCursor = true;
            // 
            // dataGridView10
            // 
            this.dataGridView10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView10.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView10.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.dataGridView10.Enabled = false;
            this.dataGridView10.Location = new System.Drawing.Point(335, 185);
            this.dataGridView10.Name = "dataGridView10";
            this.dataGridView10.RowHeadersWidth = 51;
            this.dataGridView10.RowTemplate.Height = 24;
            this.dataGridView10.Size = new System.Drawing.Size(506, 264);
            this.dataGridView10.TabIndex = 3;
            this.dataGridView10.UseWaitCursor = true;
            this.dataGridView10.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // deneme
            // 
            this.deneme.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.deneme.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.deneme.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.deneme.Location = new System.Drawing.Point(409, 465);
            this.deneme.Name = "deneme";
            this.deneme.Size = new System.Drawing.Size(196, 32);
            this.deneme.TabIndex = 4;
            this.deneme.Text = "DENEME SONUCU EKLE ";
            this.deneme.UseVisualStyleBackColor = true;
            this.deneme.UseWaitCursor = true;
            this.deneme.Click += new System.EventHandler(this.deneme_Click);
            // 
            // denemeadi
            // 
            this.denemeadi.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.denemeadi.Location = new System.Drawing.Point(452, 104);
            this.denemeadi.Name = "denemeadi";
            this.denemeadi.Size = new System.Drawing.Size(115, 22);
            this.denemeadi.TabIndex = 5;
            this.denemeadi.UseWaitCursor = true;
            // 
            // denemesonuc
            // 
            this.denemesonuc.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.denemesonuc.Location = new System.Drawing.Point(449, 135);
            this.denemesonuc.Name = "denemesonuc";
            this.denemesonuc.Size = new System.Drawing.Size(118, 22);
            this.denemesonuc.TabIndex = 6;
            this.denemesonuc.UseWaitCursor = true;
            // 
            // denemesil
            // 
            this.denemesil.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.denemesil.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.denemesil.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.denemesil.Location = new System.Drawing.Point(633, 465);
            this.denemesil.Name = "denemesil";
            this.denemesil.Size = new System.Drawing.Size(136, 32);
            this.denemesil.TabIndex = 7;
            this.denemesil.Text = "DENEMEYİ SİL";
            this.denemesil.UseVisualStyleBackColor = true;
            this.denemesil.UseWaitCursor = true;
            this.denemesil.Click += new System.EventHandler(this.denemesil_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label2.Location = new System.Drawing.Point(384, 104);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 17);
            this.label2.TabIndex = 8;
            this.label2.Text = "DERS adı";
            this.label2.UseWaitCursor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label3.Location = new System.Drawing.Point(384, 140);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 17);
            this.label3.TabIndex = 9;
            this.label3.Text = "SONUÇ";
            this.label3.UseWaitCursor = true;
            // 
            // tamamlananlarcs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.login2;
            this.ClientSize = new System.Drawing.Size(865, 547);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.denemesil);
            this.Controls.Add(this.denemesonuc);
            this.Controls.Add(this.denemeadi);
            this.Controls.Add(this.deneme);
            this.Controls.Add(this.dataGridView10);
            this.Controls.Add(this.checkedListBox1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Name = "tamamlananlarcs";
            this.Text = "tamamlananlarcs";
            this.UseWaitCursor = true;
            this.Load += new System.EventHandler(this.tamamlananlarcs_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView10)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.CheckedListBox checkedListBox1;
        private System.Windows.Forms.DataGridView dataGridView10;
        private System.Windows.Forms.Button deneme;
        private System.Windows.Forms.TextBox denemeadi;
        private System.Windows.Forms.TextBox denemesonuc;
        private System.Windows.Forms.Button denemesil;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}