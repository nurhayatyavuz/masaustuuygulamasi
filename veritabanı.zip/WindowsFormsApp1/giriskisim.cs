﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace WindowsFormsApp1
{
    public partial class giriskisim : Form
    {
        
        public giriskisim()
        {
            InitializeComponent();
        }

        SqlConnection baglanti= new SqlConnection("Data Source=LAPTOP-AA2J83E8;Initial Catalog=kutuphaneyeni;Integrated Security=True");



        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void soyadbtn_Click(object sender, EventArgs e)
        {

        }
       
        private void girisbtn_Click(object sender, EventArgs e)
        {
            
        }

            private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
         
       
        private void giriskisim_Load(object sender, EventArgs e)
        {
          
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
